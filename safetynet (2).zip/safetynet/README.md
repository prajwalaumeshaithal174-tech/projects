# SafetyNet India 🚨
### Full-Stack Incident Reporting Platform

---

## 📁 Project Structure
```
safetynet/
├── backend/
│   └── server.js          ← Express API (all endpoints)
├── frontend/
│   └── public/
│       └── index.html     ← React frontend (single file)
├── package.json
├── .replit                ← Replit config
├── .env.example           ← Copy to .env
└── README.md
```

---

## 🚀 Deploy on Replit (Recommended)

1. Go to [replit.com](https://replit.com) → Create Repl → Import from GitHub
2. Upload these files OR paste into Replit shell:
   ```bash
   git clone <your-repo> .
   npm install
   ```
3. In Replit **Secrets** (🔒 icon), add:
   - `JWT_SECRET` = any long random string
   - `TWILIO_ACCOUNT_SID` = from twilio.com
   - `TWILIO_AUTH_TOKEN` = from twilio.com
   - `TWILIO_PHONE` = your Twilio number
4. Click **Run** → Your app is live!

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/incidents` | Submit incident report |
| GET | `/api/incidents` | Get all incidents (GeoJSON + list) |
| GET | `/api/incidents/:id` | Get single incident |
| POST | `/api/authorities` | Authority login |
| POST | `/api/authorities/register` | Register new authority |
| PATCH | `/api/status/:id` | Update incident status (auth required) |
| GET | `/api/analytics` | Analytics & daily counts |
| POST | `/api/users/send-otp` | Send OTP to user phone |
| POST | `/api/users/verify-otp` | Verify OTP & login |
| GET | `/api/health` | Server health check |

---

## 🗺️ Kepler.gl Integration

The `/api/incidents` endpoint returns GeoJSON compatible with Kepler.gl.

**To visualize on Kepler.gl:**
1. Go to https://kepler.gl/demo
2. Add Data → Load Map URL
3. Enter: `https://YOUR-REPLIT-URL.repl.co/api/incidents`
4. Select the `geojson` field
5. Add heatmap layer, color by `category`

**Color mapping:**
- Red (#E24B4A) → rape, killing
- Orange (#EF9F27) → harassment
- Blue (#378ADD) → theft
- Purple (#7F77DD) → violence

---

## 🔐 Test Credentials

**Authority Login:**
- Phone: `9000000001`
- Gov ID: `GOV123456`

**User Login:**
- Any 10-digit phone → get OTP → shown in dev mode

---

## 📱 Offline SMS Fallback

When `navigator.onLine` is false:
1. Report is saved to `localStorage` queue
2. SMS is queued locally
3. When back online → `window.addEventListener('online')` fires
4. Queue flushes → all pending reports sent via Twilio

---

## 🏗️ Production Upgrades

Replace in-memory `db` object with:
- **MongoDB Atlas** (free tier) — add `mongoose` package
- **PostgreSQL** on Supabase (free tier) — add `pg` package
- **Firebase Firestore** — real-time updates built in

---

## 📞 Emergency Numbers (India)
- Police: 100
- Women Helpline: 1091
- Ambulance: 108
- Child Helpline: 1098
- Cyber Crime: 1930
