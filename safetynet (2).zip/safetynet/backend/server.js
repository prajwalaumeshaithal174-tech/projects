const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'safetynet_secret_key_2024';

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend/public')));

// ─── In-Memory Database (swap with MongoDB/PostgreSQL in production) ──────────
const db = {
  incidents: [],
  users: [],
  authorities: [
    // Pre-seeded authority for testing
    {
      id: 'auth_001',
      phone: '9000000001',
      govId: 'GOV123456',
      name: 'Inspector Ramesh Kumar',
      jurisdiction: 'Delhi',
      role: 'Police',
      passwordHash: bcrypt.hashSync('authority123', 10),
      verified: true,
      createdAt: new Date().toISOString()
    }
  ],
  smsQueue: [],
  verificationCodes: {}
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
const categoryColors = {
  rape: 'red',
  killing: 'red',
  harassment: 'orange',
  theft: 'blue',
  violence: 'purple'
};

const categoryAuthority = {
  rape: 'Police / Women Helpline (1091)',
  killing: 'Police (100)',
  harassment: 'Police / Women Helpline (1091)',
  theft: 'Police (100)',
  violence: 'Police (100) / Ambulance (108)'
};

function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

// ─── SMS Queue (Twilio integration) ──────────────────────────────────────────
async function sendSMS(to, message) {
  // If Twilio env vars are set, send real SMS
  if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
    try {
      const twilio = require('twilio');
      const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
      await client.messages.create({
        body: message,
        from: process.env.TWILIO_PHONE,
        to: `+91${to}`
      });
      return { sent: true };
    } catch (err) {
      // Queue for retry if SMS fails
      db.smsQueue.push({ to, message, queuedAt: new Date().toISOString(), attempts: 1 });
      return { sent: false, queued: true };
    }
  } else {
    // No Twilio configured — queue the message
    db.smsQueue.push({ to, message, queuedAt: new Date().toISOString(), attempts: 0 });
    return { sent: false, queued: true, note: 'Twilio not configured — queued for later' };
  }
}

async function processQueue() {
  if (db.smsQueue.length === 0) return;
  const pending = [...db.smsQueue];
  db.smsQueue = [];
  for (const sms of pending) {
    await sendSMS(sms.to, sms.message);
  }
}

// Retry queue every 5 minutes
setInterval(processQueue, 5 * 60 * 1000);

// ─── USER ROUTES ──────────────────────────────────────────────────────────────

// Send OTP for user registration/login
app.post('/api/users/send-otp', async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'Phone required' });
  const otp = generateOTP();
  db.verificationCodes[phone] = { otp, expiresAt: Date.now() + 10 * 60 * 1000 };
  await sendSMS(phone, `SafetyNet OTP: ${otp}. Valid for 10 minutes. Do not share.`);
  console.log(`[OTP] Phone: ${phone}, OTP: ${otp}`); // Log OTP since Twilio may not be set
  res.json({ success: true, message: 'OTP sent', devOtp: otp }); // devOtp only for dev
});

// Verify OTP and register/login user
app.post('/api/users/verify-otp', (req, res) => {
  const { phone, otp, email, name } = req.body;
  const record = db.verificationCodes[phone];
  if (!record || record.otp !== otp || Date.now() > record.expiresAt) {
    return res.status(400).json({ error: 'Invalid or expired OTP' });
  }
  delete db.verificationCodes[phone];
  let user = db.users.find(u => u.phone === phone);
  if (!user) {
    user = { id: uuidv4(), phone, email: email || null, name: name || null, createdAt: new Date().toISOString() };
    db.users.push(user);
  }
  const token = jwt.sign({ id: user.id, phone, role: 'user' }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ success: true, token, user: { id: user.id, phone, name: user.name, email: user.email } });
});

// ─── INCIDENT ROUTES ──────────────────────────────────────────────────────────

// POST /api/incidents — Submit new incident
app.post('/api/incidents', async (req, res) => {
  const {
    category, description, gender, anonymous,
    name, phone, email, latitude, longitude,
    address, isOnline
  } = req.body;

  if (!category || !description) {
    return res.status(400).json({ error: 'Category and description are required' });
  }

  const incident = {
    id: uuidv4(),
    category: category.toLowerCase(),
    description,
    gender: gender || 'prefer_not_to_say',
    anonymous: anonymous !== false,
    reporter: anonymous ? null : { name, phone, email },
    location: {
      latitude: latitude || null,
      longitude: longitude || null,
      address: address || null
    },
    color: categoryColors[category.toLowerCase()] || 'gray',
    authority: categoryAuthority[category.toLowerCase()] || 'Police (100)',
    status: 'pending',
    verified: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    resolvedAt: null,
    resolutionNotes: null
  };

  db.incidents.push(incident);

  // SMS fallback — alert authorities
  if (!isOnline) {
    const locationStr = latitude ? `Location: ${latitude},${longitude}` : 'Location: Unknown';
    const smsMsg = `[SafetyNet ALERT] ${category.toUpperCase()} reported. ${locationStr}. Description: ${description.substring(0, 100)}. Report ID: ${incident.id.substring(0, 8)}`;
    await sendSMS(process.env.AUTHORITY_PHONE || '9000000001', smsMsg);
    incident.smsFallbackUsed = true;
  }

  res.status(201).json({ success: true, incident });
});

// GET /api/incidents — Fetch all incidents as GeoJSON for Kepler.gl
app.get('/api/incidents', (req, res) => {
  const { category, status, from, to } = req.query;

  let filtered = db.incidents.filter(inc => {
    if (category && inc.category !== category) return false;
    if (status && inc.status !== status) return false;
    if (from && new Date(inc.createdAt) < new Date(from)) return false;
    if (to && new Date(inc.createdAt) > new Date(to)) return false;
    return true;
  });

  // GeoJSON FeatureCollection for Kepler.gl
  const geojson = {
    type: 'FeatureCollection',
    features: filtered
      .filter(inc => inc.location.latitude && inc.location.longitude)
      .map(inc => ({
        type: 'Feature',
        geometry: {
          type: 'Point',
          coordinates: [inc.location.longitude, inc.location.latitude]
        },
        properties: {
          id: inc.id,
          category: inc.category,
          color: inc.color,
          status: inc.status,
          gender: inc.gender,
          description: inc.description.substring(0, 200),
          createdAt: inc.createdAt,
          address: inc.location.address
        }
      }))
  };

  // Also return raw list for dashboard
  res.json({
    geojson,
    incidents: filtered.map(inc => ({
      ...inc,
      reporter: inc.anonymous ? null : inc.reporter
    })),
    total: filtered.length,
    byCategory: db.incidents.reduce((acc, inc) => {
      acc[inc.category] = (acc[inc.category] || 0) + 1;
      return acc;
    }, {})
  });
});

// GET single incident
app.get('/api/incidents/:id', (req, res) => {
  const incident = db.incidents.find(i => i.id === req.params.id);
  if (!incident) return res.status(404).json({ error: 'Incident not found' });
  res.json(incident);
});

// ─── AUTHORITY ROUTES ─────────────────────────────────────────────────────────

// POST /api/authorities — Authority login
app.post('/api/authorities', (req, res) => {
  const { phone, govId, password } = req.body;
  if (!phone || !govId) {
    return res.status(400).json({ error: 'Phone and Government ID required' });
  }

  const authority = db.authorities.find(a => a.phone === phone && a.govId === govId);
  if (!authority) {
    return res.status(401).json({ error: 'Invalid credentials. Verify phone and Government ID.' });
  }

  if (!authority.verified) {
    return res.status(403).json({ error: 'Account not yet verified by admin.' });
  }

  const token = jwt.sign(
    { id: authority.id, phone, role: 'authority', jurisdiction: authority.jurisdiction },
    JWT_SECRET,
    { expiresIn: '12h' }
  );

  res.json({
    success: true,
    token,
    authority: {
      id: authority.id,
      name: authority.name,
      jurisdiction: authority.jurisdiction,
      role: authority.role
    }
  });
});

// Register new authority (admin approval flow)
app.post('/api/authorities/register', (req, res) => {
  const { phone, govId, name, jurisdiction, role } = req.body;
  if (!phone || !govId || !name) {
    return res.status(400).json({ error: 'Phone, Government ID, and name required' });
  }
  if (db.authorities.find(a => a.phone === phone || a.govId === govId)) {
    return res.status(409).json({ error: 'Authority already registered' });
  }
  const authority = {
    id: uuidv4(),
    phone, govId, name,
    jurisdiction: jurisdiction || 'National',
    role: role || 'Police',
    verified: false, // Requires admin approval
    createdAt: new Date().toISOString()
  };
  db.authorities.push(authority);
  res.status(201).json({ success: true, message: 'Registration submitted. Await admin verification.' });
});

// ─── STATUS ROUTES ────────────────────────────────────────────────────────────

// PATCH /api/status/:id — Update incident resolution
app.patch('/api/status/:id', authMiddleware, (req, res) => {
  if (req.user.role !== 'authority') {
    return res.status(403).json({ error: 'Only authorities can update status' });
  }

  const incident = db.incidents.find(i => i.id === req.params.id);
  if (!incident) return res.status(404).json({ error: 'Incident not found' });

  const { status, verified, resolutionNotes } = req.body;

  if (status) incident.status = status;
  if (verified !== undefined) incident.verified = verified; // true = real, false = fake
  if (resolutionNotes) incident.resolutionNotes = resolutionNotes;
  incident.updatedAt = new Date().toISOString();
  if (status === 'resolved') incident.resolvedAt = new Date().toISOString();
  incident.resolvedBy = req.user.id;

  res.json({ success: true, incident });
});

// ─── ANALYTICS ROUTES ─────────────────────────────────────────────────────────

app.get('/api/analytics', (req, res) => {
  const now = new Date();
  const last30days = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(now);
    d.setDate(d.getDate() - (29 - i));
    return d.toISOString().split('T')[0];
  });

  const dailyCounts = last30days.map(date => {
    const count = db.incidents.filter(inc => inc.createdAt.startsWith(date)).length;
    const byCategory = db.incidents
      .filter(inc => inc.createdAt.startsWith(date))
      .reduce((acc, inc) => { acc[inc.category] = (acc[inc.category] || 0) + 1; return acc; }, {});
    return { date, count, ...byCategory };
  });

  res.json({
    dailyCounts,
    totals: {
      total: db.incidents.length,
      pending: db.incidents.filter(i => i.status === 'pending').length,
      resolved: db.incidents.filter(i => i.status === 'resolved').length,
      fake: db.incidents.filter(i => i.verified === false).length,
      confirmed: db.incidents.filter(i => i.verified === true).length
    },
    byCategory: db.incidents.reduce((acc, inc) => {
      acc[inc.category] = (acc[inc.category] || 0) + 1;
      return acc;
    }, {})
  });
});

// ─── SMS Queue status ─────────────────────────────────────────────────────────
app.get('/api/sms-queue', authMiddleware, (req, res) => {
  res.json({ queue: db.smsQueue, count: db.smsQueue.length });
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    incidents: db.incidents.length,
    authorities: db.authorities.length,
    smsQueue: db.smsQueue.length,
    timestamp: new Date().toISOString()
  });
});

// ─── Catch-all → serve frontend ───────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ SafetyNet server running on port ${PORT}`);
  console.log(`📍 API endpoints ready:`);
  console.log(`   POST /api/incidents`);
  console.log(`   GET  /api/incidents`);
  console.log(`   POST /api/authorities`);
  console.log(`   PATCH /api/status/:id`);
  console.log(`   GET  /api/analytics`);
});
